Rails.application.routes.draw do
  root :to => 'homes#top'
  resources :books
  # post "books/:id/destroy" => "books#destroy"
  # post "books/update" => "books#update"
  # post "books/create" => "books#create"
  # get "books/:id/show" => "books#show"
  # get "books/:id/edit" => "books#edit"
  # get "books/index" => "books#index"
  # get "/" => "homes#top"
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
