require 'test_helper'

class BooksControllerTest < ActionDispatch::IntegrationTest
  test "should get newd" do
    get books_newd_url
    assert_response :success
  end

end
